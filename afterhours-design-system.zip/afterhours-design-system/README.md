# Afterhours Fitness Co.

Joint-friendly home workouts for men 35+, hosted by **Max Reverb** — a 46-year-old former warehouse DJ (an AI-created character). The brand looks like the last hour of a warehouse rave: concrete-black rooms, one neon sign, brushed chrome. Updated to the v9 merged homepage (Oct 2026); first built from the site files in Google Drive (`afterhours-site-2026-10-01-v4.zip`).

![Afterhours mark](/_blob/b768e29d56022ea9c673b69227e6df92)

## Voice

- **Short, dry, nightlife-flavored.** Club words stand in for gym words: sessions are *sets*, the lineup, house rules, the afterparty, last call. "Still here at 4am." "Doors 10PM · Last call never."
- **Plain promises, no hype.** "No gym, no ego, no wrecked knees." Numbers over adjectives: *1 piece of gear*, *20 min or less*, *35+*.
- **Joints first, always.** Safety lines are stated flatly: "Pain means stop." Never shame, never "beast mode".
- **Honest about Max.** Every surface that shows Max says he is AI-created ("His images and videos are AI-generated. The workouts are real."). Affiliate content carries `#ad · As an Amazon Associate I earn from qualifying purchases.` and "Not medical advice."
- Headlines are UPPERCASE in the display face; body copy is sentence case.

## Visual foundations

- **Dark only.** The page is `bg` (#0a0a0b); bands alternate with `bg-2`; panels sit on `card` with a 1px `line` border, and raised parts inside a panel use `card-2`. Text steps down `text` → `muted` → `faint`. There is no light theme.
- **One neon.** `acid` (#b6ff2e) is the only hue. Use it for the call to action, the eyebrow, numbers, the second half of a headline, hover borders and focus rings. Text on acid is `bg`. Don't tint large areas with it; it is a sign, not a wall.
- **Chrome.** Headline first halves and stat numbers use the chrome gradient (`chrome-white` 0% → `chrome-light` 40% → `chrome-dark` 55% → `chrome-bright` 75% → `chrome-end` 100%, top to bottom) clipped to text. Pair one chrome phrase with one acid phrase: *Still here* / *at 4am.*
- **Glow, sparingly.** The only shadow is `glow-acid` on button hover, plus soft radial acid washes (`acid` at ~12% alpha) behind the hero and final CTA. On the Gear page the wordmark sets in Anton acid with a 12px acid text-shadow, like a neon sign.
- **Shapes.** Pills for buttons, inputs and tags (`radius-pill`), `radius-card` (18px) panels, `radius-panel` (14px) for FAQ items and options, `radius-photo` for photos, `radius-bar` (4px) on bars, and square-ish `radius-shop` (3px) on Shop buttons only. Cards lift 3px and swap their border to acid on hover.
- **Dashed rules for lists.** Exercise, gear and pick lists separate rows with 1px dashed `line` rules; solid rules are for section edges.
- **Motion.** The hero equalizer bars scale between 35% and 100% height over 1.2s, alternating acid and chrome bars; switch off under `prefers-reduced-motion`.
- **Layout.** `content-max` 1100px with `space-20` gutters, `space-90` section padding, 3-column card and rule grids that drop to 2 under 860px and 1 under 560px.

## Type

- **Anton** Regular for everything display, uppercase with 0.015em tracking and 0.98 leading (file in `fonts/Anton-Regular.ttf`, SIL Open Font License in `fonts/OFL.txt`): H1, H2, card titles, stats, numbering. Uppercase, slight positive tracking, tight leading (.95).
- **Inter** 400–800 (Google Fonts) for body (16.5px), buttons (700), eyebrows (700, 0.22em, led by a 26px acid dash), uppercase labels (800, 0.2em) and the wordmark (800, 0.14em).
- Anton is bundled with this system. Inter loads from `https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap`.

## Logo and iconography

- Single-color versions: `afterhours-mark-mono-white.svg` (on photos and dark grounds), `afterhours-mark-mono-black.svg` (on light grounds, acid, print), `afterhours-mark-knockout-black.svg` (a black tile with the bars cut out, for stamps and watermarks).
- The mark is four equalizer bars on a `card` tile: three `acid`, the third `chrome-light`. Next to it, the wordmark is set in Inter 700: **AFTERHOURS** with **FITNESS CO.** small and tracked beneath, in `muted`. There is no drawn wordmark file; set it in type.
- Icons are simple 24px line icons, 2px stroke, round caps, `currentColor` (acid inside an `acid-dim` tile). One icon per session: pull-up bar, band, kettlebell, foam roller, ab wheel, shaker.

## Photography

Max in his brick loft: exposed brick, factory windows, warm practical lamps, a green neon AFTERHOURS sign, record shelves. Wardrobe is acid-lime or charcoal tees; bathroom sets use a charcoal towel and night light. Products are plain and unbranded. Every image is AI-generated and is labeled with the "AI CREATED" tag where Max appears.

## Components

- **Homepage:** Button, Eyebrow, SessionCard, HouseRule, FaqItem, AINote.
- **Gear page (commerce):** PickBadge, ShopButton, GearCard, GearListItem, PhotoFrame, CarouselControls. Retail buttons use `radius-shop` (3px) and an `acid-border` outline; the rest of the system stays rounded.
- **Beard Routine (pick-your-path):** StepProgress, ChoiceOption, RoutinePick. Kept as they were, with v9 type: Anton A/B letters, 800-weight labels, 8px progress bar.
- **Marketing:** PinTemplate.
- **No prices or star ratings on our pages.** Amazon Associates only allows them when they come live from Amazon (its product API or an Amazon-served link). Shop buttons say "Check price on Amazon" instead.
- **v9 homepage:** Chip, JumpChips, EmailSignup, StatRow, FollowLinks, ProductCard. The workout player (timer, queue, sound toggle) lives in the homepage code and is not a component here yet.

All render with the tokens above and use the bundled Anton file and Inter from Google Fonts (bundle.css imports it).

## Pinterest pins

Pins are 1000×1500 (2:3, `pin-width` × `pin-height`). One photo fills the top two-thirds and fades into `bg`; the headline sits low in Anton at 132px, first line chrome, second line acid, two lines max. Footer: mark, AFTERHOURS / FITNESS CO., and the disclosure on the right.

- **Product pin:** a MAX'S PICK badge, a short CTA ("Shop the bar"), and `#ad · As an Amazon Associate I earn from qualifying purchases. Max is an AI-created character.`
- **Motivation pin:** a house rule or quote, no CTA, no product link. Quotes from living public figures stay off product pins.
- **Brand pin:** no photo, the tagline and the site URL.
- Every pin with Max carries the AI CREATED tag.

## Known variants

`workouts-sessions.html` (Oct 10 draft) uses an amber accent (#e8b04a) and warmer text (#f2f0eb). It is not part of this system; acid is the brand accent.
