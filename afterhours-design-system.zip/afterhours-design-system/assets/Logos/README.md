# Logos

- `afterhours-mark.svg` — the equalizer mark on its `card` tile, full color (acid + chrome-light). 28px in the nav, 64px for app icons.
- `afterhours-mark-mono-white.svg` — bars only, white, transparent ground. On photos and dark grounds.
- `afterhours-mark-mono-black.svg` — bars only, `bg` black. On light grounds, on acid, and in print.
- `afterhours-mark-knockout-black.svg` — black tile with the bars cut out. Stamps, watermarks, one-color merch.

Keep clear space of at least one bar width around the bars. Never recolor the bars individually in the mono versions.
