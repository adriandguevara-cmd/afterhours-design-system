# Photography

AI-generated images of Max Reverb from the site (`max.jpg`, `img/`). Brick loft, neon AFTERHOURS sign, acid-lime or charcoal wardrobe. Always disclose as AI-created when Max appears.

- `max-reverb.jpg` — studio portrait, hero image (800×1000)
- `door.jpg`, `pullup.jpg`, `onesie.jpg` — doorway pull-up bar
- `loft.jpg`, `loft2.jpg`, `kb.jpg` — loft with neon sign
- `bands.jpg` — band work
- `coffee.jpg` — fall evening, sofa
- `brush.jpg`, `deo.jpg`, `mirror.jpg`, `wash.jpg` — After-Shower Reset bathroom set
