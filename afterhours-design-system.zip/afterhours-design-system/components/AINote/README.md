The dashed AI-disclosure note that sits next to any image or video of Max.

Required wherever Max appears. Defaults to the standard wording; pass children to adapt it.
