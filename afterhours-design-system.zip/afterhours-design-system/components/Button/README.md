Primary (acid) and secondary (ghost) pill buttons.

Use one acid button per view for the main action; ghost for the second. Labels are sentence case and short ("See the sessions", "Shop the gear →"). `size="sm"` in the nav. Pass `href` to render a link.
