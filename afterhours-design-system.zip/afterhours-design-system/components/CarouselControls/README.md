Arrow buttons and dots for a gear carousel.

The consumer owns the active index and scrolls the track; the active dot glows acid.
