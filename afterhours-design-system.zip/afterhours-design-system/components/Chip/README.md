An uppercase pill tag for durations, joint notes and product shorthand.

`hot` turns it acid for the one tag that matters most. Group in `.ah-chips`.
