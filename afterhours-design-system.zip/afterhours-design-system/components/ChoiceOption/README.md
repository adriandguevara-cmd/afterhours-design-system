An A/B product choice card from the Beard Routine builder: key square, option label, product, short note.

Always two side by side (one column under 620px). Selecting one advances to the next step.
