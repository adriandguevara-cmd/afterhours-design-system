The email capture: pill input plus acid button, with fine print under it.

The consumer provides `onSubmit` to send the address to the mail provider; the component then shows a confirmation box. Stacks vertically under 900px.
