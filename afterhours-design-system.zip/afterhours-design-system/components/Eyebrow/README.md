The uppercase acid kicker above every section heading.

One short phrase ("The lineup", "House rules"). Always followed by a display heading.
