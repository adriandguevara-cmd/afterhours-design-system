A collapsible question panel (native details/summary, no JavaScript needed).

The consumer provides the answer as children. Keep answers practical; safety caveats stated plainly.
