Max's social links as three tiny equalizer tiles (TikTok, Instagram, Pinterest), each a different bar pattern.

Sits in the nav's upper right. The pattern is the icon, so keep the aria-labels.
