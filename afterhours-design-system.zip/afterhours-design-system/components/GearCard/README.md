A swipeable gear card from the Gear page: count, Anton title, optional Max's pick, description and Shop button.

Use in a horizontal scroll-snap track, one card per view, beside a PhotoFrame that swaps with the active card. Pair with CarouselControls.
