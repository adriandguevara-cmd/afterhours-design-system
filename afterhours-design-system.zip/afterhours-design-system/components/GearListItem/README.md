A product row for still lists (the Kitchen restock): title, one-line note, Shop button on the right.

Stacks vertically under 720px.
