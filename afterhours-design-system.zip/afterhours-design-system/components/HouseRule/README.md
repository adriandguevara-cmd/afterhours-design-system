A numbered rule with an acid left rule: number, heading, one sentence.

Use in sets of three. Numbers are two digits ("01").
