A row of pill links that jump to sections on the page (sore spots, rooms, sets).

Use under a section head; keep labels to one or two words.
