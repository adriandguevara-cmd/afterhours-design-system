A 4:3 rounded photo frame with the AI CREATED tag.

The tag is on by default and must stay on for any image of Max. Provide alt text that describes the scene.
