The neon "Max's pick" pill that marks the item Max uses himself.

Sits inline after a gear title. One per item; never on every item in a list.
