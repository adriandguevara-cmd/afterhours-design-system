A gear card with a white product-photo square, optional MAX'S PICK badge, Anton title, a one-line note and a full-width "Check price on Amazon" button.

Two per row on the gear grid, one under 620px. Without `img` it shows a "Product photo" placeholder. No prices, sale prices or star ratings: Amazon Associates only allows those when they come live from Amazon's own API or an Amazon-served link, so a typed-in "$29.99" or "4.6 ★" can get the account flagged and goes stale. The page needs the Amazon Associate disclosure nearby.
