One row of the finished routine: step label, chosen product, "Amazon ›" link.

Group rows under a phase label (`.ah-phase`) such as "In the shower · daily".
