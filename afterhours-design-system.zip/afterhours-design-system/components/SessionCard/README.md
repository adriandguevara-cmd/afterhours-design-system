A workout session card: icon, Anton title, muted description and a "Main gear" footer.

Lay out three across (two under 860px, one under 560px) with `space-18` gaps. Provide a 24px line icon with 2px stroke in `currentColor`. Hover lifts 3px and turns the border acid.
