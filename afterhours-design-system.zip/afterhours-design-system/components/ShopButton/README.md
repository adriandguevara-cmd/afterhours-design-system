The squared, acid-outlined "Shop on Amazon" link used on every product.

Anton label, `radius-shop` corners (the retail edge, not a pill). Pass `href`; it renders with `rel="sponsored noopener"`. The page it sits on must carry the Amazon Associate disclosure.
