The hero stat row: chrome Anton numbers over tracked uppercase labels, above a hairline.

Three stats max, short labels.
