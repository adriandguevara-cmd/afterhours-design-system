The thin acid progress bar with "Step 04 / 4 of 9" meta from the Beard Routine builder.

Pass `done` on the result screen.
