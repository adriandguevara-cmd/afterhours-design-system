import type { ReactNode, ButtonHTMLAttributes } from "react";
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> { /** acid = primary CTA, ghost = secondary */ variant?: "acid" | "ghost"; /** sm is the nav size */ size?: "md" | "sm"; /** renders an <a> when set */ href?: string; children: ReactNode; }
export interface EyebrowProps { children: ReactNode; className?: string; }
export interface SessionCardProps { title: string; /** 24px line icon, 2px stroke, currentColor */ icon?: ReactNode; /** e.g. "Kettlebell" */ gear?: string; /** default "Main gear" */ gearLabel?: string; href?: string; children: ReactNode; }
export interface HouseRuleProps { /** "01" */ n: string; title: string; children: ReactNode; }
export interface FaqItemProps { /** "Q1" */ n?: string; question: string; defaultOpen?: boolean; children: ReactNode; }
export interface AINoteProps { /** defaults to the standard Max disclosure */ children?: ReactNode; }
export declare function Button(p: ButtonProps): JSX.Element;
export declare function Eyebrow(p: EyebrowProps): JSX.Element;
export declare function SessionCard(p: SessionCardProps): JSX.Element;
export declare function HouseRule(p: HouseRuleProps): JSX.Element;
export declare function FaqItem(p: FaqItemProps): JSX.Element;
export declare function AINote(p: AINoteProps): JSX.Element;
export interface PickBadgeProps { /** solid acid pill (on product images) */ solid?: boolean; /** default "Max's pick" */ children?: ReactNode; }
export interface ShopButtonProps { href?: string; /** full-width, as on gear cards */ block?: boolean; /** default "Shop on Amazon" */ children?: ReactNode; }
export interface GearCardProps { /** "01 / 06" */ count?: string; title: string; pick?: boolean; href?: string; cta?: string; children: ReactNode; }
export interface GearListItemProps { title: string; pick?: boolean; href?: string; cta?: string; children: ReactNode; }
export interface PhotoFrameProps { src: string; alt?: string; /** CSS aspect-ratio, default "4/3" */ ratio?: string; /** default true: shows the AI CREATED tag */ aiTag?: boolean; }
export interface CarouselControlsProps { count: number; active: number; onChange?: (i: number) => void; }
export interface StepProgressProps { step: number; total: number; done?: boolean; }
export interface ChoiceOptionProps { k?: "A" | "B"; label: string; product: string; note?: string; selected?: boolean; onClick?: () => void; }
export interface RoutinePickProps { /** "01 · Wash the beard" */ step: string; product: string; href: string; go?: string; }
export interface PinTemplateProps { variant?: "product" | "motivation" | "brand"; photo?: string; /** CSS background-position for the photo crop, default "center 25%"; use e.g. "75% 30%" when Max is off-center */ photoPosition?: string; eyebrow?: string; /** first headline line, chrome */ chrome?: string; /** second headline line, acid */ acid?: string; sub?: string; cta?: string; /** top-left acid pill, e.g. "MAX'S PICK" */ badge?: string; aiTag?: boolean; /** overrides the default disclosure for the variant */ disclosure?: string; }
export declare function PickBadge(p: PickBadgeProps): JSX.Element;
export declare function ShopButton(p: ShopButtonProps): JSX.Element;
export declare function GearCard(p: GearCardProps): JSX.Element;
export declare function GearListItem(p: GearListItemProps): JSX.Element;
export declare function PhotoFrame(p: PhotoFrameProps): JSX.Element;
export declare function CarouselControls(p: CarouselControlsProps): JSX.Element;
export declare function StepProgress(p: StepProgressProps): JSX.Element;
export declare function ChoiceOption(p: ChoiceOptionProps): JSX.Element;
export declare function RoutinePick(p: RoutinePickProps): JSX.Element;
export declare function PinTemplate(p: PinTemplateProps): JSX.Element;
export interface ChipProps { hot?: boolean; children: ReactNode; }
export interface JumpChipsProps { label?: string; items: { label: string; href: string }[]; }
export interface EmailSignupProps { placeholder?: string; cta?: string; fine?: string; doneText?: string; onSubmit?: (email: string) => void; }
export interface StatRowProps { items: { value: string; label: string }[]; }
export interface FollowLinksProps { links: { tiktok?: string; instagram?: string; pinterest?: string }; }
export interface ProductCardProps { title: string; img?: string; alt?: string; pick?: boolean | string; href?: string; cta?: string; children?: ReactNode; }
export declare function Chip(p: ChipProps): JSX.Element;
export declare function JumpChips(p: JumpChipsProps): JSX.Element;
export declare function EmailSignup(p: EmailSignupProps): JSX.Element;
export declare function StatRow(p: StatRowProps): JSX.Element;
export declare function FollowLinks(p: FollowLinksProps): JSX.Element;
export declare function ProductCard(p: ProductCardProps): JSX.Element;
